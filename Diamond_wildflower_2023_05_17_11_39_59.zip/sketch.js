class edificio{
  
  constructor(cColor, x, y) {
    this.color = "grey";
    this.x = x;
    this.y = y;
    this.puertas = 2;
  }
  
  construir() {
    fill(this.color);
    rect(this.x, this.y, 50);
  }
}

class casa {
  
}

function mouseClicked() {
}

class hospital extends edificio{
  
  constructor(cColor, x, y) {
    super(cColor, x, y);
    this.color = "red";
  }
  construir(){
    fill(this.color);
    rect(this.x, this.y, 75)
  }
  
}

let edificio1;
let edificio2;
let hospital1;

function setup() {
  createCanvas(400, 400);
  background(119, 194, 103, 76);
  edificio1 = new edificio(this.color, 33, 33);
  edificio1.construir();
  edificio2 = new edificio(this.color, 100, 33);
  edificio2.construir();
  hospital1 = new hospital(this.color, 200, 33);
  hospital1.construir();
}

