class edificio{
  
  constructor(cColor, x, y) {
    this.color = cColor;
    this.x = x;
    this.y = y;
    this.puertas = 2;
  }
  
  construir() {
    fill(this.color);
    rect(this.x, this.y, 50);
  }
}

class casa {
  
}

let edificio1;
let edificio2;

function setup() {
  createCanvas(400, 400);
  background(119, 194, 103, 76);
  edificio1 = new edificio("red", 30, 30);
  edificio1.construir();
  edificio2 = new edificio("purple", 100, 30);
  edificio2.construir();
}

function mouseClicked() {
  ;
}